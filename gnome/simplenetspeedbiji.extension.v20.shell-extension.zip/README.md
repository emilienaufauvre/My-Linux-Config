# Simple net speed 
Gnome extension to show network speed

https://extensions.gnome.org/extension/1085/simple-net-speed/

Simply showing network speed. Left click to change modes:

1. Total net speed in bits per second
1. Total net speed in Bytes per second
1. Up & down speed in bits per second
1. Up & down speed in Bytes per second
1. Total of downloaded in Bytes (Right click to reset counter)

Middle click to change font size
